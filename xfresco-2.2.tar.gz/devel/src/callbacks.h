#include <gtk/gtk.h>


void
on_main_window_destroy                 (GtkObject       *object,
                                        gpointer         user_data);

void
on_file_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_New_activate                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_Open_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_import_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_print_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_revert_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_Save_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_Save_as_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_Exit_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_Edit_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_Show_input_activate                 (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_run_activate                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_Run_options_activate                (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_Run_activate                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_kill_current_activate               (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_check_stdout_activate               (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_files_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_About_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_Version_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

gboolean
on_main_notebook_key_press_event       (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data);

gboolean
on_main_notebook_key_release_event     (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data);

void
on_button_open_ccwf_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_use_ccwf_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_jbord_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_entry_elab_changed                  (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_toggle_elab_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_elab1_changed                       (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_check_mtmin_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_toggle_2ntrans_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

gboolean
on_label_integration_button_press_event
                                        (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data);

void
on_opt_lampl_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_ldistrib_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_open_Rmatrix_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_band_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_partition_add_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_partition_replace_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_partition_insert_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_partition_delete_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_partitions_select_row               (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_states_replace_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_states_insert_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_states_add_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_states_delete_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_states_select_row                   (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_combo_type_changed_selection        (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_potential_add_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_potential_insert_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_potential_replace_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_potential_delete_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_pot_clist_select_row                (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_step_state_changed_value            (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_step_add_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_step_insert_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_step_replace_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_step_delete_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_step_clist_select_row               (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_kind_overlap_changed                (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_over_be_changed                     (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_check_vary_be_clicked               (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_misc_bins_press_event               (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data);

void
on_overlap_add_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_overlap_insert_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_overlap_replace_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_overlap_delete_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_overlap_clist_select_row            (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_combo_kind_changed_selection        (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_check_k8_ip2_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_coupling_add_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_coupling_insert_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_coupling_replace_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_coupling_delete_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_coup_clist_select_row               (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_inel_clist_select_row               (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data);

gboolean
on_label_inel_pressed                  (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data);

void
on_cfp_ibia_changed                    (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_cfp_clist_select_row                (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data);

gboolean
on_qscale_focus_out_event              (GtkWidget       *widget,
                                        GdkEventFocus   *event,
                                        gpointer         user_data);

void
on_cfp_add_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_cfp_insert_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_cfp_replace_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_cfp_delete_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_open_filesel_delete_ev              (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_open_filesel_ok_button_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_open_filesel_cancel_button_clicked  (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_window_constants_delete_event       (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_button_constants_close_clicked      (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_window_ccwf_delete_event            (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_ccwf_ok_button_clicked              (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_window_jbord_delete_event           (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_jbord_ok_button_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_save_filesel_ok_button_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_save_filesel_cancel_button_clicked  (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_window_nlab_delete_event            (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_window_nlab_ok_clicked              (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_window_files_delete_event           (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

gboolean
on_window_Rmatrix_delete_event         (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_Rmat_ok_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_window_ener_delete_event            (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_elab2_changed                       (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_elab3_changed                       (GtkEditable     *editable,
                                        gpointer         user_data);
